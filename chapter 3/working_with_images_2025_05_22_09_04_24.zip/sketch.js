let pic;
function preload(){
  pic=loadImage("MyPhoto.png")
}
function setup() {
  createCanvas(400, 400);
  
  background(94, 66, 182);
  //to call the function mask
  clip(mask);
  image(pic,50,50,275,275)
}
function mask() {
  circle(200,200,250);
}
function draw()
{
  frameRate(15)
  let x = random(width);
  let y = random(height);
  let r = random(20, 80);
  
  fill(random(255),random(255), random(255), 50);
  strokeWeight(0)
  ellipse(x,y,r,r);
  
  fill(255)
  textSize(20)
  textAlign(CENTER,CENTER)
  text("CAT",200,200)
}

