let song
let rectHeigth = 0

function preload(){
  song = loadSound("NobodyNew.mp3")
}

function setup() {
  createCanvas(400, 400);
  background(0);
  song.play();
  amp = new p5.Amplitude()
}

function draw() {
  let songLevel = amp.getLevel() * height * 0.5;
  let songLevel1 = amp.getLevel() * height *1;
  let songLevel2 = amp.getLevel() * height *1.5;
  background(0);
  
  fill(random(255), random(255), random(255));
  rect(20, height - songLevel - 50, 50, songLevel);
  rect(90, height - songLevel1 - 50, 50, songLevel1);
  rect(160, height - songLevel2 - 50, 50, songLevel2);
  rect(230, height - songLevel1 - 50, 50, songLevel1);
  rect(300, height - songLevel - 50, 50, songLevel);
  fill(0)
  
  for (i = 20; i < width; i += 15) {
    strokeWeight(5);
    fill("255"); 
    line(i*0.01,i , i*20, i);
  }
}