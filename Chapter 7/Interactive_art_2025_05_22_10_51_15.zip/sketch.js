let spaceX = 20
let spaceY = 20
let diam = 10

function setup(){
  createCanvas(600, 400);
  noStroke();
}

function draw(){
  background(225,224,219);
  
  for (let x = 20; x < width; x += spaceX){
    for (let y = 20 ; y < height; y += spaceY){
      let redBall = dist (mouseX, mouseY, x, y)
      if(redBall < 100){
        fill(255,0,0,200)
        diam = map(redBall, 0, 100, 55, 5)
      }
      else{
        fill(114,190,226)
        diam = 10
      }
      ellipse(x, y, diam);
    }
  }
}