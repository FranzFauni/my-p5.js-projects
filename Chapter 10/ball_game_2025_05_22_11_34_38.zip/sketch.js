let ballX, ballY, ballSpeedX,ballSpeedY
let paddleX, paddleW
let score = 0;
let gameOver = false;
let bg_music
let catbar
let popcat
let hard_mode


function preload(){
  bg_music = loadSound('cat_game_music.mp3')
  catbar = loadImage('longcat.png')
  popcat = loadImage('popcat.png')
  fire = loadImage('fire.gif')
  hard_mode = loadSound('Hardmode.mp3')
}

function setup() {
  createCanvas(600, 400);
  startGame();
  bg_music.play()
}



function draw() {
  background(118,181,197);
  
  
  if(!gameOver){
    ballX += ballSpeedX;
    ballY += ballSpeedY;
    
    
    if(ballX < 0 || ballX > width) ballSpeedX *= -1;
    if(ballY < 0) ballSpeedY *= -1;
    
    paddleX = constrain(mouseX - 50, 0, width - paddleW);
    
    
    if(
    ballY + 10 >= height - 20&&
    ballX > paddleX&&
    ballX < paddleX + paddleW
    ) {
      ballSpeedY *= -1;
      ballSpeedX *= 1.25
      score ++
    }
    
    if (score >= 5){
      hardMode()
    } 
    
    if (
    ballY + 10 >= height - 20&&
    ballX > paddleX&&
    ballX < paddleX + paddleW&&
    score ==5
    ){
      hard_mode.play();
    }
    
    
    if (ballY> height - 23) gameOver = true;
    
    fill(255);
    ellipse(ballX, ballY, 20);
    image(popcat, ballX-25, ballY-25, 45, 45)
    
    
    rect(paddleX, height - 20, paddleW, 10)
    image(catbar,paddleX -10, 292, 130, 130);
    
    fill(255);
    textSize(16);
    text("score: " + score, width / 2 , height / 10);
  }
    else{
      fill(255);
      textAlign(CENTER);
      textSize(32);
      text("Game Over", width / 2, height / 2 - 20);
      textSize(20);
      text("Your score: " + score, width / 2, height / 2 + 20)
      text("Click to restart", width / 2, height / 2 + 45);
      text("All music made by Franz Fauni", width / 2, height / 2 + 70)
      bg_music.stop()
      hard_mode.stop()
  }
  
}

function mousePressed() {
  if (gameOver) {
    startGame();
    bg_music.play()
  }
}

function startGame() {
  ballX = random(1, 400);
  ballY = random(3, 200);
  ballSpeedX = 4;
  ballSpeedY = 4;
  paddleW = 100;
  score = 0;
  gameOver = false;
}

function hardMode(){
   bg_music.pause();
   background(0)
   fill(255,0,0)
   text("HARD MODE",50, 170, 100)
   text("HARD MODE",450, 170,100)
   image(fire, paddleX,280, 110, 110)
   image(fire, 150, 10, 280, 280)
}