let a
let b
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(84, 45, 139);
  
  //alien
    //body
  b = random(20,180)
  strokeWeight(3)
  fill(57, 87, 128);
  ellipse(200,195,59,95);
  strokeWeight(2)
  fill(b, b, b)
  ellipse(220,181,6,9);
  fill(255, b, 0)
  ellipse(215,181,6,9);
  fill(b, 255, 0)
  ellipse(210,181,6,9);
    //antena
  strokeWeight(2)
  line (197,91,185,70);
  line (201,91,215,76)
  fill(0);
  strokeWeight(3)
  circle(185,70,6);
  circle(215,76,6);
    //alien head
  strokeWeight(3);
  fill(66, 107, 50);
  ellipse(200,130,70,75);
  arc(200,125,69,100, radians(0),radians(180))
    //alien eyes
  strokeWeight(0);
  fill(0);
  ellipse(188,125,13,29);
  ellipse(212,125,13,29);
    //ears
  ellipse(165,130,10,20)
  ellipse(235,130,10,20)
    //nose
  strokeWeight(2)
  line(197,150,197,160)
  line(203,150,203,160)
  line(191,150,191,160)
  line(209,150,209,160)
  
  //ufo
  strokeWeight(3)
     //window
  fill(224, 224, 224, 80);
  arc(200,210,300,400,radians(180),radians(0));
  
    //base
  fill(187);
  ellipse(200,240, 380, 100);
   //the bottom bit thingy
  arc(200,275,230,70,radians(0), radians(180))
  
  //details
    //lights
  a = random(10,180)
  fill(191, 73, 73)
  ellipse(200,230,30)
  ellipse(345,245,30,20)
  ellipse(56,245,30,20)
    //BEAM
  fill(a, 154, 182,120)
  ellipse(200,290,50,30)
  strokeWeight(0)
  fill(a, 154, 182,120)
  triangle(200,290,100,410,300,410)
 
  
  
}