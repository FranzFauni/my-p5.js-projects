function setup() {
  createCanvas(400,400);
  background(247, 205, 153)
  
  fill(108, 165, 230);
  stroke(108, 165, 230)
  strokeWeight(4);

  rectMode(CENTER);
  let gaps = 48;
  for (x=0;x<width;x+=gaps){
    for (y=0;y<height;y+=gaps){
      square(x,y,25)
      square(x+gaps/2,y+gaps/2,13)
      circle(x+gaps/2,y+gaps/2,15)
      circle(x,y,29)
      
    }
  }
}