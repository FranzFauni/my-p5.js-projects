 let typing = "";

function setup() {
  createCanvas(400, 400);
  background(252, 213, 144);
  textSize(30)  
}


function draw() {
  background(252, 213, 144);
  frameRate(5)
  fill(random(255),random(255),random(255))
  text(typing, random(50, 300), random(70, 360))
  fill(255)
  text("Jittery Text", 130, 40)
}

function keyTyped(){
  typing += key;
}

function mousePressed(){
  typing = "";
}