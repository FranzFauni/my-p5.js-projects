let table;
let GSW;
let CLA;
let MA;
let MB;
let DM


function preload(){
  table = loadTable('highest NBA 3 point shooters.csv', 'csv', 'header');
  GSW = loadImage("GSW.png")
  CLA = loadImage("CLA.png")
  MA = loadImage('MA.png')
  MB = loadImage("MB.png")
  DM = loadImage("DM.png")
}

function setup(){
  createCanvas(600, 400);
}

function draw(){
  background(255);
  
  let barWidth = 100;
  
  for(let i = 0; i < table.getRowCount(); i++){
    let module = table.getString(i, 'Player Name');
    let marks = table.getNum(i, '3 point goals');
    
    let x = 22 + i * (barWidth + 14);
    let h = map(marks, 0, 4500, 0, height);
    
    fill(0);
    rect(x, height - h, barWidth, h);
    
    fill(255);
    textAlign(CENTER);
    textSize(12);
    text(module, x + barWidth / 2, height - 20);
    text(marks, x + barWidth / 2, height - 50);
    
    fill(0)
    textSize(20)
    text("Top NBA 3 point scores", 290, 50)
    
    image(GSW,45, 275, 55, 55)
    image(CLA,148, 275, 75, 58)
    image(MA, 237, 275, 125, 58)
    image(MB, 386, 275, 55, 55)
    image(DM, 499, 275, 55, 55)
  }
}