let tail = [];

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(30,129,176);
  tail.push(createVector(mouseX, mouseY));
  
  if (tail.length > 50) {
    tail.shift();
  }
  for (let i = 0; i < tail.length; i++) {
    let pos = tail[i];
    fill(226,135,67)
    ellipse(pos.x, pos.y, i / 2);
  }
  
}
